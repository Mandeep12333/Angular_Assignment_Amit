export class Employee {
    ID:Number | undefined;
    FName:String | undefined;
    LName:String | undefined;
    Country:String | undefined;
    Email:string | undefined;
    Password:String | undefined;
}

